package com.example.workoutmaker;

public enum MuscleGroup {
    CHEST, SHOULDERS, BIS, TRIS, BACK, QUADS, HAMS, CALF, CORE, LATS, GLUTES, NONE
}
